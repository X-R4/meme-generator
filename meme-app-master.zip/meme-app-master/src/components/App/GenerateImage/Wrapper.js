import styled from 'styled-components';

const Wrapper = styled.section`
    text-align: center;
`;

export default Wrapper;
