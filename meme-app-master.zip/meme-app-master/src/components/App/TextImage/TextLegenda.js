import styled from 'styled-components';

const TextLegenda = styled.p`
    font-style: italic;
    font-size: 0.875em;
`;

export default TextLegenda;
